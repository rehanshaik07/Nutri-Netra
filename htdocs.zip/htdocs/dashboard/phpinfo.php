<?php phpinfo(); ?>

