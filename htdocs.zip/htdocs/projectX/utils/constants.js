// Application Constants

// API Endpoints (for future backend integration)
const API = {
    BASE_URL: 'https://api.nutri-netra.com/v1',
    ENDPOINTS: {
        LOGIN: '/auth/login',
        SCHOOLS: '/schools',
        MENU: '/menu',
        ATTENDANCE: '/attendance',
        WASTAGE: '/wastage',
        FEEDBACK: '/feedback',
        USERS: '/users',
        REPORTS: '/reports'
    }
};

// Meal Types
const MEAL_TYPES = {
    BREAKFAST: { id: 'breakfast', name: 'Breakfast', time: '8:00 AM', icon: '🥣' },
    LUNCH: { id: 'lunch', name: 'Lunch', time: '12:30 PM', icon: '🍗' },
    SNACK: { id: 'snack', name: 'Snack', time: '3:00 PM', icon: '🍎' }
};

// Food Categories
const FOOD_CATEGORIES = {
    VEGETABLES: { id: 'veg', name: 'Vegetables', color: '#2a9d8f' },
    GRAINS: { id: 'grains', name: 'Grains', color: '#e9c46a' },
    PROTEIN: { id: 'protein', name: 'Protein', color: '#f4a261' },
    FRUITS: { id: 'fruits', name: 'Fruits', color: '#2c7da0' },
    DAIRY: { id: 'dairy', name: 'Dairy', color: '#e76f51' }
};

// User Roles
const USER_ROLES = {
    ADMIN: 'admin',
    STAFF: 'staff',
    STUDENT: 'student',
    VIEWER: 'viewer'
};

// Chart Colors
const CHART_COLORS = {
    PRIMARY: '#2c7da0',
    SECONDARY: '#e9c46a',
    ACCENT: '#f4a261',
    SUCCESS: '#2a9d8f',
    DANGER: '#e76f51',
    INFO: '#4a90e2',
    DARK: '#2d3e50',
    LIGHT: '#f8f9fa'
};

// Date Formats
const DATE_FORMATS = {
    DISPLAY: 'MM/DD/YYYY',
    API: 'YYYY-MM-DD',
    DISPLAY_LONG: 'MMMM DD, YYYY',
    TIME: 'hh:mm A'
};

// Default Settings
const DEFAULTS = {
    SCHOOL_ID: 1,
    MAX_MEALS_PER_DAY: 500,
    DEFAULT_CURRENCY: 'USD',
    NOTIFICATION_DURATION: 3000,
    CHART_ANIMATION_DURATION: 1000
};

// Messages
const MESSAGES = {
    LOGIN_SUCCESS: 'Login successful! Redirecting...',
    LOGIN_ERROR: 'Invalid credentials. Please try again.',
    SAVE_SUCCESS: 'Data saved successfully!',
    SAVE_ERROR: 'Error saving data. Please try again.',
    DELETE_CONFIRM: 'Are you sure you want to delete this item?',
    NETWORK_ERROR: 'Network error. Please check your connection.',
    SESSION_EXPIRED: 'Session expired. Please login again.'
};

// Export for use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { API, MEAL_TYPES, FOOD_CATEGORIES, USER_ROLES, CHART_COLORS, DATE_FORMATS, DEFAULTS, MESSAGES };
}

