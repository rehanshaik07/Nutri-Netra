// Helper Functions

// Format Currency
function formatCurrency(amount, currency = 'USD') {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: currency
    }).format(amount);
}

// Format Percentage
function formatPercentage(value, decimals = 1) {
    return `${value.toFixed(decimals)}%`;
}

// Calculate Average
function calculateAverage(numbers) {
    if (!numbers.length) return 0;
    return numbers.reduce((sum, num) => sum + num, 0) / numbers.length;
}

// Group By Function
function groupBy(array, key) {
    return array.reduce((result, item) => {
        const groupKey = item[key];
        if (!result[groupKey]) result[groupKey] = [];
        result[groupKey].push(item);
        return result;
    }, {});
}

// Sort By Date
function sortByDate(array, dateField = 'date', order = 'desc') {
    return [...array].sort((a, b) => {
        const dateA = new Date(a[dateField]);
        const dateB = new Date(b[dateField]);
        return order === 'desc' ? dateB - dateA : dateA - dateB;
    });
}

// Filter By Date Range
function filterByDateRange(array, dateField, startDate, endDate) {
    return array.filter(item => {
        const itemDate = new Date(item[dateField]);
        return itemDate >= new Date(startDate) && itemDate <= new Date(endDate);
    });
}

// Generate Random ID
function generateId(prefix = 'id') {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

// Deep Clone Object
function deepClone(obj) {
    return JSON.parse(JSON.stringify(obj));
}

// Validate Email
function isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

// Validate Phone Number
function isValidPhone(phone) {
    const re = /^[\+]?[(]?[0-9]{1,4}[)]?[-\s\.]?[(]?[0-9]{1,4}[)]?[-\s\.]?[0-9]{1,5}[-\s\.]?[0-9]{1,5}$/;
    return re.test(phone);
}

// Truncate Text
function truncateText(text, maxLength = 100) {
    if (text.length <= maxLength) return text;
    return text.substr(0, maxLength) + '...';
}

// Capitalize First Letter
function capitalizeFirst(str) {
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
}

// Get Week Number
function getWeekNumber(date) {
    const d = new Date(date);
    const dayNum = d.getUTCDay() || 7;
    d.setUTCDate(d.getUTCDate() + 4 - dayNum);
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    return Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
}

// Download File
function downloadFile(content, filename, type = 'text/plain') {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
}

// Read File as Text
function readFileAsText(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(reader.error);
        reader.readAsText(file);
    });
}

// Get Query Parameter
function getQueryParam(param) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
}

// Set Query Parameter
function setQueryParam(param, value) {
    const url = new URL(window.location.href);
    url.searchParams.set(param, value);
    window.history.pushState({}, '', url);
}

// Local Storage Wrapper
const storage = {
    set: (key, value) => localStorage.setItem(key, JSON.stringify(value)),
    get: (key, defaultValue = null) => {
        const item = localStorage.getItem(key);
        return item ? JSON.parse(item) : defaultValue;
    },
    remove: (key) => localStorage.removeItem(key),
    clear: () => localStorage.clear()
};

// Session Storage Wrapper
const session = {
    set: (key, value) => sessionStorage.setItem(key, JSON.stringify(value)),
    get: (key, defaultValue = null) => {
        const item = sessionStorage.getItem(key);
        return item ? JSON.parse(item) : defaultValue;
    },
    remove: (key) => sessionStorage.removeItem(key),
    clear: () => sessionStorage.clear()
};

// Export for use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        formatCurrency,
        formatPercentage,
        calculateAverage,
        groupBy,
        sortByDate,
        filterByDateRange,
        generateId,
        deepClone,
        isValidEmail,
        isValidPhone,
        truncateText,
        capitalizeFirst,
        getWeekNumber,
        downloadFile,
        readFileAsText,
        getQueryParam,
        setQueryParam,
        storage,
        session
    };
}

