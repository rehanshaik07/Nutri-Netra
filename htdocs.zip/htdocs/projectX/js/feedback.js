// Feedback System JavaScript
let currentRating = 0;

document.addEventListener('DOMContentLoaded', function() {
    initFeedbackPage();
    loadFeedbackList();
    setupStarRating();
});

function initFeedbackPage() {
    loadFeedbackStats();
    loadMealDropdown();
}

function loadFeedbackStats() {
    const stats = {
        totalFeedbacks: 45,
        averageRating: 4.6,
        totalResponses: 89,
        responseRate: 92
    };
    
    document.getElementById('totalFeedbacks') && (document.getElementById('totalFeedbacks').innerText = stats.totalFeedbacks);
    document.getElementById('avgFeedbackRating') && (document.getElementById('avgFeedbackRating').innerText = stats.averageRating);
    document.getElementById('totalResponses') && (document.getElementById('totalResponses').innerText = stats.totalResponses);
    document.getElementById('responseRate') && (document.getElementById('responseRate').innerText = stats.responseRate + '%');
}

function loadMealDropdown() {
    const mealSelect = document.getElementById('feedbackMeal');
    if (!mealSelect) return;
    
    const meals = [
        { id: 1, name: 'Vegetable Stir-fry' },
        { id: 2, name: 'Grilled Chicken Bowl' },
        { id: 3, name: 'Vegan Lentil Soup' },
        { id: 4, name: 'Cheese Pasta' }
    ];
    
    mealSelect.innerHTML = '<option value="">Select a meal</option>' + 
        meals.map(meal => `<option value="${meal.id}">${meal.name}</option>`).join('');
}

function setupStarRating() {
    const stars = document.querySelectorAll('.star-rating .star');
    stars.forEach(star => {
        star.addEventListener('click', function() {
            currentRating = parseInt(this.getAttribute('data-rating'));
            stars.forEach((s, index) => {
                if (index < currentRating) {
                    s.classList.add('selected');
                } else {
                    s.classList.remove('selected');
                }
            });
            document.getElementById('ratingValue').value = currentRating;
        });
        
        star.addEventListener('mouseover', function() {
            const rating = parseInt(this.getAttribute('data-rating'));
            stars.forEach((s, index) => {
                if (index < rating) {
                    s.style.color = '#ffc107';
                } else {
                    s.style.color = '#ddd';
                }
            });
        });
        
        star.addEventListener('mouseout', function() {
            stars.forEach((s, index) => {
                if (index < currentRating) {
                    s.style.color = '#ffc107';
                } else {
                    s.style.color = '#ddd';
                }
            });
        });
    });
}

function loadFeedbackList() {
    const container = document.getElementById('feedbackList');
    if (!container) return;
    
    const feedbacks = [
        { name: 'Emma Watson', rating: 5, comment: 'Delicious and healthy!', meal: 'Grilled Chicken Bowl', date: '2024-01-20' },
        { name: 'Liam Chen', rating: 4, comment: 'Good portion size', meal: 'Vegetable Stir-fry', date: '2024-01-20' },
        { name: 'Sophia R.', rating: 5, comment: 'Loved the vegan option', meal: 'Vegan Lentil Soup', date: '2024-01-19' },
        { name: 'James Wilson', rating: 5, comment: 'Excellent quality', meal: 'Grilled Chicken Bowl', date: '2024-01-19' }
    ];
    
    container.innerHTML = feedbacks.map(f => `
        <div class="feedback-card">
            <div class="feedback-header">
                <div>
                    <strong><i class="fas fa-user"></i> ${f.name}</strong>
                    <div class="stars-display">${'⭐'.repeat(f.rating)}</div>
                </div>
                <small>${f.date}</small>
            </div>
            <p class="feedback-meal"><i class="fas fa-utensils"></i> ${f.meal}</p>
            <p class="feedback-comment">"${f.comment}"</p>
        </div>
    `).join('');
}

document.getElementById('feedbackForm')?.addEventListener('submit', function(e) {
    e.preventDefault();
    
    if (currentRating === 0) {
        showNotification('Please select a rating', 'error');
        return;
    }
    
    const feedbackData = {
        studentName: document.getElementById('studentName').value,
        mealId: document.getElementById('feedbackMeal').value,
        rating: currentRating,
        comment: document.getElementById('feedbackComment').value,
        date: new Date().toISOString().split('T')[0]
    };
    
    if (!feedbackData.mealId) {
        showNotification('Please select a meal', 'error');
        return;
    }
    
    // In production, send to backend
    showNotification('Thank you for your feedback!', 'success');
    this.reset();
    currentRating = 0;
    document.querySelectorAll('.star-rating .star').forEach(star => {
        star.classList.remove('selected');
        star.style.color = '#ddd';
    });
    
    setTimeout(() => loadFeedbackList(), 500);
});

