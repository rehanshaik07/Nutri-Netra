// Multi-School Selection Handler
document.addEventListener('DOMContentLoaded', function() {
    initSchoolSelector();
});

function initSchoolSelector() {
    const schoolSelect = document.getElementById('schoolSelect');
    if (!schoolSelect) return;
    
    // Load schools into dropdown
    if (typeof SCHOOLS_DATA !== 'undefined') {
        schoolSelect.innerHTML = SCHOOLS_DATA.schools.map(school => 
            `<option value="${school.id}" ${window.currentSchool?.id == school.id ? 'selected' : ''}>${school.name}</option>`
        ).join('');
    }
    
    // Add change event listener
    schoolSelect.addEventListener('change', function() {
        const schoolId = this.value;
        const selectedSchool = SCHOOLS_DATA?.getSchoolById(schoolId);
        
        if (selectedSchool) {
            localStorage.setItem('currentSchool', JSON.stringify(selectedSchool));
            window.currentSchool = selectedSchool;
            
            // Update UI elements that show school name
            document.querySelectorAll('.school-name-display').forEach(el => {
                el.innerText = selectedSchool.name;
            });
            
            showNotification(`Switched to ${selectedSchool.name}`, 'success');
            
            // Reload page data if needed
            if (typeof updateDashboard === 'function') {
                updateDashboard();
            }
        }
    });
}

function getCurrentSchool() {
    return window.currentSchool || JSON.parse(localStorage.getItem('currentSchool') || '{"id":1,"name":"Green Valley High School"}');
}

function switchSchool(schoolId) {
    const schoolSelect = document.getElementById('schoolSelect');
    if (schoolSelect) {
        schoolSelect.value = schoolId;
        schoolSelect.dispatchEvent(new Event('change'));
    }
}

