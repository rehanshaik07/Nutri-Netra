// Food Wastage Analysis JavaScript
let wastageChart = null;
let wastageCategoryChart = null;

document.addEventListener('DOMContentLoaded', function() {
    initWastagePage();
});

function initWastagePage() {
    loadWastageStats();
    loadWastageByMealType();
    loadWastageByCategory();
    loadDailyWastageTrend();
    loadReductionSuggestions();
}

function loadWastageStats() {
    const stats = {
        totalWeek: 47.2,
        avgPerDay: 9.4,
        costLost: 235,
        targetPerDay: 8,
        reduction: 15
    };
    
    document.getElementById('totalWaste') && (document.getElementById('totalWaste').innerHTML = `${stats.totalWeek}kg<small>This Week</small>`);
    document.getElementById('avgWaste') && (document.getElementById('avgWaste').innerHTML = `${stats.avgPerDay}kg<small>Per Day</small>`);
    document.getElementById('costLost') && (document.getElementById('costLost').innerHTML = `$${stats.costLost}<small>Lost</small>`);
    document.getElementById('wasteTarget') && (document.getElementById('wasteTarget').innerHTML = `<${stats.targetPerDay}kg<small>Target/Day</small>`);
}

function loadWastageByMealType() {
    const ctx = document.getElementById('wastageMealChart')?.getContext('2d');
    if (!ctx) return;
    
    if (wastageChart) wastageChart.destroy();
    
    wastageChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Breakfast', 'Lunch', 'Snack'],
            datasets: [{
                label: 'Wastage (kg)',
                data: [8.2, 12.5, 2.8],
                backgroundColor: ['#e9c46a', '#2c7da0', '#f4a261'],
                borderRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { position: 'bottom' },
                tooltip: { callbacks: { label: (ctx) => `${ctx.raw} kg (${((ctx.raw / 23.5) * 100).toFixed(1)}%)` } }
            }
        }
    });
}

function loadWastageByCategory() {
    const ctx = document.getElementById('wastageCategoryChart')?.getContext('2d');
    if (!ctx) return;
    
    if (wastageCategoryChart) wastageCategoryChart.destroy();
    
    wastageCategoryChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Vegetables', 'Grains', 'Protein', 'Fruits', 'Dairy'],
            datasets: [{
                data: [4.5, 3.8, 3.2, 2.5, 1.8],
                backgroundColor: ['#2c7da0', '#e9c46a', '#f4a261', '#2a9d8f', '#e76f51'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { position: 'right' },
                tooltip: { callbacks: { label: (ctx) => `${ctx.label}: ${ctx.raw} kg` } }
            }
        }
    });
}

function loadDailyWastageTrend() {
    const ctx = document.getElementById('dailyWastageTrend')?.getContext('2d');
    if (!ctx) return;
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
            datasets: [{
                label: 'Wastage (kg)',
                data: [10.2, 8.5, 7.8, 9.2, 11.5],
                borderColor: '#e76f51',
                backgroundColor: 'rgba(231, 111, 81, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                tooltip: { callbacks: { label: (ctx) => `${ctx.raw} kg` } }
            }
        }
    });
}

function loadReductionSuggestions() {
    const suggestionsContainer = document.getElementById('reductionSuggestions');
    if (!suggestionsContainer) return;
    
    const suggestions = [
        { icon: 'fa-cut', text: 'Reduce portion size of rice by 15% (most wasted item)', impact: 'High' },
        { icon: 'fa-child', text: 'Offer half-portions for younger students', impact: 'Medium' },
        { icon: 'fa-box', text: 'Implement "take-home" program for untouched food', impact: 'High' },
        { icon: 'fa-poll', text: 'Survey students about disliked vegetables', impact: 'Medium' },
        { icon: 'fa-chart-line', text: 'Track and adjust menu based on consumption data', impact: 'High' }
    ];
    
    suggestionsContainer.innerHTML = suggestions.map(s => `
        <div class="suggestion-item">
            <div class="suggestion-icon"><i class="fas ${s.icon}"></i></div>
            <div class="suggestion-content">
                <p>${s.text}</p>
                <span class="impact-badge impact-${s.impact.toLowerCase()}">${s.impact} Impact</span>
            </div>
        </div>
    `).join('');
}

function exportWastageReport() {
    const data = [
        { Category: 'Vegetables', Wastage_kg: 4.5, Percentage: 19 },
        { Category: 'Grains', Wastage_kg: 3.8, Percentage: 16 },
        { Category: 'Protein', Wastage_kg: 3.2, Percentage: 14 },
        { Category: 'Fruits', Wastage_kg: 2.5, Percentage: 11 },
        { Category: 'Dairy', Wastage_kg: 1.8, Percentage: 8 }
    ];
    exportToCSV(data, 'wastage-report.csv');
    showNotification('Wastage report exported');
}

