// Admin Panel JavaScript
let currentEditUserId = null;
let users = [
    { id: 1, username: 'admin', role: 'admin', email: 'admin@school.com', status: 'active', lastLogin: '2024-01-20' },
    { id: 2, username: 'john_doe', role: 'staff', email: 'john@school.com', status: 'active', lastLogin: '2024-01-19' },
    { id: 3, username: 'jane_smith', role: 'viewer', email: 'jane@school.com', status: 'inactive', lastLogin: '2024-01-15' }
];

// Initialize Admin Panel
document.addEventListener('DOMContentLoaded', function() {
    if (!window.isAdmin) {
        showNotification('Access denied. Admin only.', 'error');
        setTimeout(() => window.location.href = '../dashboard.html', 2000);
        return;
    }
    
    initAdminTabs();
    loadAdminStats();
    loadUsersTable();
    loadSchoolsGrid();
    loadActivityLog();
    loadSystemSettings();
});

function initAdminTabs() {
    const tabs = document.querySelectorAll('.admin-tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            
            tabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            document.querySelectorAll('.tab-pane').forEach(pane => {
                pane.classList.remove('active');
            });
            document.getElementById(tabId).classList.add('active');
        });
    });
}

function loadAdminStats() {
    const stats = {
        totalSchools: SCHOOLS_DATA?.schools.length || 3,
        totalStudents: 2750,
        totalMeals: 18234,
        avgRating: 4.6,
        wasteReduction: 15,
        activeUsers: users.filter(u => u.status === 'active').length
    };
    
    document.getElementById('totalSchools') && (document.getElementById('totalSchools').innerText = stats.totalSchools);
    document.getElementById('totalStudents') && (document.getElementById('totalStudents').innerText = formatNumber(stats.totalStudents));
    document.getElementById('totalMeals') && (document.getElementById('totalMeals').innerText = formatNumber(stats.totalMeals));
    document.getElementById('avgRating') && (document.getElementById('avgRating').innerText = stats.avgRating);
    document.getElementById('wasteReduction') && (document.getElementById('wasteReduction').innerText = stats.wasteReduction + '%');
    document.getElementById('activeUsers') && (document.getElementById('activeUsers').innerText = stats.activeUsers);
}

function loadUsersTable() {
    const tbody = document.getElementById('usersTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = users.map(user => `
        <tr>
            <td>${user.username}</td>
            <td>${user.role}</td>
            <td>${user.email}</td>
            <td><span class="status-badge ${user.status}">${user.status}</span></td>
            <td>${user.lastLogin}</td>
            <td class="action-buttons">
                <button class="action-btn edit-btn" onclick="editUser(${user.id})"><i class="fas fa-edit"></i></button>
                <button class="action-btn delete-btn" onclick="deleteUser(${user.id})"><i class="fas fa-trash"></i></button>
            </td>
        </tr>
    `).join('');
}

function loadSchoolsGrid() {
    const grid = document.getElementById('schoolsGrid');
    if (!grid || !SCHOOLS_DATA) return;
    
    grid.innerHTML = SCHOOLS_DATA.schools.map(school => `
        <div class="school-card">
            <div class="school-card-header">
                <i class="fas fa-school"></i>
                <span class="school-status ${school.activeMealProgram ? 'active' : 'inactive'}">
                    ${school.activeMealProgram ? 'Active' : 'Inactive'}
                </span>
            </div>
            <h3>${school.name}</h3>
            <p><i class="fas fa-map-marker-alt"></i> ${school.address}</p>
            <div class="school-stats">
                <p><i class="fas fa-users"></i> Students: ${school.totalStudents}</p>
                <p><i class="fas fa-utensils"></i> Capacity: ${school.mealCapacity}</p>
            </div>
            <div class="action-buttons">
                <button class="action-btn edit-btn" onclick="editSchool(${school.id})">Edit</button>
                <button class="action-btn" onclick="viewSchoolReports(${school.id})">Reports</button>
            </div>
        </div>
    `).join('');
}

function loadActivityLog() {
    const logContainer = document.getElementById('activityLog');
    if (!logContainer) return;
    
    const activities = [
        { icon: 'fa-user-plus', action: 'New user added', user: 'Admin', time: '10 mins ago', details: 'Added user "sarah_johnson"' },
        { icon: 'fa-edit', action: 'Menu updated', user: 'Admin', time: '1 hour ago', details: 'Updated weekly menu for next week' },
        { icon: 'fa-download', action: 'Report exported', user: 'John Doe', time: '3 hours ago', details: 'Exported waste report for January' },
        { icon: 'fa-comment', action: 'Feedback moderated', user: 'Admin', time: '5 hours ago', details: 'Reviewed 12 new feedback entries' },
        { icon: 'fa-cog', action: 'Settings changed', user: 'Admin', time: 'Yesterday', details: 'Updated system configuration' }
    ];
    
    logContainer.innerHTML = activities.map(activity => `
        <div class="activity-item">
            <div class="activity-icon"><i class="fas ${activity.icon}"></i></div>
            <div class="activity-details">
                <p><strong>${activity.action}</strong> by ${activity.user}</p>
                <p>${activity.details}</p>
                <small>${activity.time}</small>
            </div>
        </div>
    `).join('');
}

function loadSystemSettings() {
    const settings = {
        systemName: 'Nutri-Netra',
        maintenanceMode: false,
        maxMealsPerDay: 500,
        defaultCurrency: 'USD',
        emailNotifications: true,
        autoBackup: true
    };
    
    document.getElementById('systemName') && (document.getElementById('systemName').value = settings.systemName);
    document.getElementById('maintenanceMode') && (document.getElementById('maintenanceMode').value = settings.maintenanceMode);
    document.getElementById('maxMealsPerDay') && (document.getElementById('maxMealsPerDay').value = settings.maxMealsPerDay);
    document.getElementById('defaultCurrency') && (document.getElementById('defaultCurrency').value = settings.defaultCurrency);
}

function openUserModal(editMode = false) {
    const modal = document.getElementById('userModal');
    if (modal) {
        document.getElementById('modalTitle').innerText = editMode ? 'Edit User' : 'Add New User';
        modal.classList.add('active');
    }
}

function closeUserModal() {
    const modal = document.getElementById('userModal');
    if (modal) {
        modal.classList.remove('active');
        document.getElementById('userForm').reset();
        currentEditUserId = null;
    }
}

function editUser(id) {
    const user = users.find(u => u.id === id);
    if (user) {
        currentEditUserId = id;
        document.getElementById('userUsername').value = user.username;
        document.getElementById('userEmail').value = user.email;
        document.getElementById('userRole').value = user.role;
        document.getElementById('userStatus').value = user.status;
        openUserModal(true);
    }
}

function deleteUser(id) {
    if (confirm('Are you sure you want to delete this user?')) {
        users = users.filter(u => u.id !== id);
        loadUsersTable();
        showNotification('User deleted successfully');
    }
}

function editSchool(id) {
    const school = SCHOOLS_DATA.getSchoolById(id);
    if (school) {
        alert(`Edit school: ${school.name}\nThis feature would open an edit form.`);
    }
}

function viewSchoolReports(id) {
    window.location.href = `../dashboard.html?school=${id}`;
}

function exportSystemData() {
    const data = {
        users: users,
        schools: SCHOOLS_DATA?.schools || [],
        exportDate: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nutri-netra-export-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showNotification('Data exported successfully');
}

document.getElementById('userForm')?.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const userData = {
        id: currentEditUserId || users.length + 1,
        username: document.getElementById('userUsername').value,
        email: document.getElementById('userEmail').value,
        role: document.getElementById('userRole').value,
        status: document.getElementById('userStatus').value,
        lastLogin: currentEditUserId ? users.find(u => u.id === currentEditUserId)?.lastLogin : new Date().toISOString().split('T')[0]
    };
    
    if (currentEditUserId) {
        const index = users.findIndex(u => u.id === currentEditUserId);
        if (index !== -1) users[index] = userData;
        showNotification('User updated successfully');
    } else {
        users.push(userData);
        showNotification('User added successfully');
    }
    
    closeUserModal();
    loadUsersTable();
});

document.getElementById('settingsForm')?.addEventListener('submit', function(e) {
    e.preventDefault();
    showNotification('Settings saved successfully');
    // In production, save to backend
});

