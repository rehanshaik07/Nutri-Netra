// Dashboard functionality
let attendanceChart = null;

function updateDashboard() {
    // Simulate fetching data based on selected school and date range
    const schoolId = document.getElementById('schoolSelect')?.value || '1';
    const startDate = document.getElementById('startDate')?.value;
    const endDate = document.getElementById('endDate')?.value;
    
    // Update stats with mock data
    document.getElementById('totalMeals').innerText = '1,245';
    document.getElementById('attendanceRate').innerText = '89%';
    document.getElementById('wastage').innerText = '12.5kg';
    document.getElementById('avgRating').innerText = '4.5/5';
    
    // Update today's menu
    updateTodayMenu();
    
    // Update attendance chart
    updateAttendanceChart();
    
    // Update recent feedback
    updateRecentFeedback();
    
    // Update smart insight
    updateSmartInsight();
}

function updateTodayMenu() {
    const menuContainer = document.getElementById('todayMenu');
    const todayMenuData = {
        breakfast: { name: "Oatmeal with Fresh Fruits", icon: "🥣", time: "8:00 AM" },
        lunch: { name: "Grilled Chicken with Brown Rice", icon: "🍗", time: "12:30 PM" },
        snack: { name: "Apple Slices with Yogurt", icon: "🍎", time: "3:00 PM" }
    };
    
    menuContainer.innerHTML = `
        <div class="menu-item">
            <div class="menu-icon">${todayMenuData.breakfast.icon}</div>
            <div class="menu-details">
                <strong>Breakfast</strong>
                <p>${todayMenuData.breakfast.name}</p>
                <small>${todayMenuData.breakfast.time}</small>
            </div>
        </div>
        <div class="menu-item">
            <div class="menu-icon">${todayMenuData.lunch.icon}</div>
            <div class="menu-details">
                <strong>Lunch</strong>
                <p>${todayMenuData.lunch.name}</p>
                <small>${todayMenuData.lunch.time}</small>
            </div>
        </div>
        <div class="menu-item">
            <div class="menu-icon">${todayMenuData.snack.icon}</div>
            <div class="menu-details">
                <strong>Snack</strong>
                <p>${todayMenuData.snack.name}</p>
                <small>${todayMenuData.snack.time}</small>
            </div>
        </div>
    `;
}

function updateAttendanceChart() {
    const ctx = document.getElementById('attendanceChart')?.getContext('2d');
    if (!ctx) return;
    
    if (attendanceChart) attendanceChart.destroy();
    
    attendanceChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
            datasets: [{
                label: 'Attendance %',
                data: [85, 82, 78, 88, 92],
                borderColor: '#2c7da0',
                backgroundColor: 'rgba(44, 125, 160, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });
}

function updateRecentFeedback() {
    const feedbackContainer = document.getElementById('recentFeedback');
    const feedbacks = [
        { name: "Emma Watson", rating: 5, comment: "Great meal today!", date: "Today" },
        { name: "Liam Chen", rating: 4, comment: "Loved the pasta option", date: "Yesterday" },
        { name: "Sophia R.", rating: 5, comment: "Very healthy and tasty", date: "Yesterday" }
    ];
    
    feedbackContainer.innerHTML = feedbacks.map(f => `
        <div class="feedback-item">
            <div class="feedback-header">
                <strong>${f.name}</strong>
                <div class="stars">${'⭐'.repeat(f.rating)}</div>
            </div>
            <p>"${f.comment}"</p>
            <small>${f.date}</small>
        </div>
    `).join('');
}

function updateSmartInsight() {
    const insightContainer = document.getElementById('smartInsight');
    const insights = [
        "💡 Attendance dropped 5% on Wednesday. Consider sending reminders to parents.",
        "📊 Vegetable waste increased by 15%. Try offering more variety.",
        "⭐ Feedback shows 92% satisfaction with new menu items.",
        "🎯 On track to reduce food waste by 20% this month!"
    ];
    
    const randomInsight = insights[Math.floor(Math.random() * insights.length)];
    insightContainer.innerHTML = `<p class="insight-text">${randomInsight}</p>`;
}

// Initialize dashboard
document.addEventListener('DOMContentLoaded', () => {
    updateDashboard();
    
    // Set default dates
    const today = new Date();
    const weekAgo = new Date(today);
    weekAgo.setDate(today.getDate() - 7);
    
    document.getElementById('startDate').value = weekAgo.toISOString().split('T')[0];
    document.getElementById('endDate').value = today.toISOString().split('T')[0];
});

