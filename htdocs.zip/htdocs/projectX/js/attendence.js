// Attendance Tracking JavaScript
let attendanceChart = null;

document.addEventListener('DOMContentLoaded', function() {
    initAttendancePage();
});

function initAttendancePage() {
    loadAttendanceStats();
    loadAttendanceChart();
    loadDailyBreakdown();
    setupAttendanceFilters();
}

function loadAttendanceStats() {
    const stats = {
        avgDaily: 312,
        totalMonthly: 6240,
        peakDay: { day: 'Friday', rate: 89 },
        lowDay: { day: 'Tuesday', rate: 82 },
        weeklyTrend: '+5%'
    };
    
    document.getElementById('avgDaily') && (document.getElementById('avgDaily').innerText = stats.avgDaily);
    document.getElementById('totalMonthly') && (document.getElementById('totalMonthly').innerText = formatNumber(stats.totalMonthly));
    document.getElementById('peakDay') && (document.getElementById('peakDay').innerHTML = `${stats.peakDay.day}<small>${stats.peakDay.rate}%</small>`);
    document.getElementById('lowDay') && (document.getElementById('lowDay').innerHTML = `${stats.lowDay.day}<small>${stats.lowDay.rate}%</small>`);
}

function loadAttendanceChart() {
    const ctx = document.getElementById('attendanceTrendChart')?.getContext('2d');
    if (!ctx) return;
    
    if (attendanceChart) attendanceChart.destroy();
    
    attendanceChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
            datasets: [
                {
                    label: 'Breakfast',
                    data: [78, 82, 85, 88],
                    borderColor: '#e9c46a',
                    backgroundColor: 'rgba(233, 196, 106, 0.1)',
                    tension: 0.4
                },
                {
                    label: 'Lunch',
                    data: [85, 88, 92, 94],
                    borderColor: '#2c7da0',
                    backgroundColor: 'rgba(44, 125, 160, 0.1)',
                    tension: 0.4
                },
                {
                    label: 'Snack',
                    data: [65, 70, 72, 75],
                    borderColor: '#f4a261',
                    backgroundColor: 'rgba(244, 162, 97, 0.1)',
                    tension: 0.4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: { position: 'bottom' },
                tooltip: { callbacks: { label: (ctx) => `${ctx.dataset.label}: ${ctx.raw}%` } }
            },
            scales: { y: { min: 0, max: 100, ticks: { callback: (v) => v + '%' } } }
        }
    });
}

function loadDailyBreakdown() {
    const tbody = document.getElementById('dailyBreakdownBody');
    if (!tbody) return;
    
    const dailyData = [
        { date: '2024-01-15', breakfast: 245, lunch: 312, snack: 189, total: 746, change: '+5%', trend: 'up' },
        { date: '2024-01-16', breakfast: 238, lunch: 298, snack: 176, total: 712, change: '-4%', trend: 'down' },
        { date: '2024-01-17', breakfast: 256, lunch: 325, snack: 198, total: 779, change: '+9%', trend: 'up' },
        { date: '2024-01-18', breakfast: 242, lunch: 308, snack: 182, total: 732, change: '-6%', trend: 'down' },
        { date: '2024-01-19', breakfast: 268, lunch: 342, snack: 212, total: 822, change: '+12%', trend: 'up' }
    ];
    
    tbody.innerHTML = dailyData.map(day => `
        <tr>
            <td>${day.date}</td>
            <td>${day.breakfast}</td>
            <td>${day.lunch}</td>
            <td>${day.snack}</td>
            <td><strong>${day.total}</strong></td>
            <td class="${day.trend === 'up' ? 'trend-up' : 'trend-down'}">
                ${day.change} ${day.trend === 'up' ? '▲' : '▼'}
            </td>
        </tr>
    `).join('');
}

function setupAttendanceFilters() {
    const schoolSelect = document.getElementById('attendanceSchool');
    const dateRange = document.getElementById('attendanceDateRange');
    
    if (schoolSelect) {
        schoolSelect.addEventListener('change', () => {
            showNotification('Updating attendance data...', 'info');
            loadAttendanceChart();
        });
    }
    
    if (dateRange) {
        dateRange.addEventListener('change', () => {
            loadAttendanceChart();
        });
    }
}

function exportAttendanceReport() {
    const data = [
        { Date: '2024-01-15', Breakfast: 245, Lunch: 312, Snack: 189, Total: 746 },
        { Date: '2024-01-16', Breakfast: 238, Lunch: 298, Snack: 176, Total: 712 },
        { Date: '2024-01-17', Breakfast: 256, Lunch: 325, Snack: 198, Total: 779 }
    ];
    exportToCSV(data, 'attendance-report.csv');
    showNotification('Report exported successfully');
}

