// Main JavaScript - Session Management & Common Functions

// Check authentication on every page
function checkAuth() {
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    const currentPage = window.location.pathname.split('/').pop();
    
    // If not logged in and not on login page, redirect to login
    if (!isLoggedIn && currentPage !== 'index.html' && currentPage !== '') {
        window.location.href = 'index.html';
        return false;
    }
    
    // If logged in and on login page, redirect to dashboard
    if (isLoggedIn && (currentPage === 'index.html' || currentPage === '')) {
        window.location.href = 'dashboard.html';
        return false;
    }
    
    return true;
}

// Logout function
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        // Clear all storage
        localStorage.clear();
        sessionStorage.clear();
        
        // Redirect to login page
        window.location.href = 'index.html';
    }
}

// Get current user info
function getCurrentUser() {
    return {
        isLoggedIn: localStorage.getItem('isLoggedIn') === 'true',
        role: localStorage.getItem('userRole'),
        name: localStorage.getItem('userName'),
        email: localStorage.getItem('userEmail'),
        schoolId: localStorage.getItem('schoolId'),
        loginTime: localStorage.getItem('loginTime')
    };
}

// Check if user is admin
function isAdmin() {
    return localStorage.getItem('userRole') === 'admin';
}

// Check if user is student
function isStudent() {
    return localStorage.getItem('userRole') === 'student';
}

// Session timeout check (30 minutes)
function checkSessionTimeout() {
    const loginTime = localStorage.getItem('loginTime');
    if (loginTime) {
        const timeSinceLogin = (new Date() - new Date(loginTime)) / 1000 / 60; // minutes
        if (timeSinceLogin > 30) {
            logout();
            alert('Your session has expired. Please login again.');
        }
    }
}

// Initialize app with session check
document.addEventListener('DOMContentLoaded', function() {
    // Check authentication
    checkAuth();
    
    // Check session timeout every minute
    setInterval(checkSessionTimeout, 60000);
    
    // Load user info in UI if logged in
    const userInfo = getCurrentUser();
    if (userInfo.isLoggedIn) {
        // Update user display elements
        const userNameElements = document.querySelectorAll('.user-name-display, #userNameDisplay');
        userNameElements.forEach(el => {
            if (el) el.innerText = userInfo.name;
        });
        
        // Show/hide admin-only elements
        if (!isAdmin()) {
            document.querySelectorAll('.admin-only').forEach(el => {
                el.style.display = 'none';
            });
        }
    }
});

// Export for use in other files
window.logout = logout;
window.getCurrentUser = getCurrentUser;
window.isAdmin = isAdmin;
window.isStudent = isStudent;
window.checkAuth = checkAuth;

