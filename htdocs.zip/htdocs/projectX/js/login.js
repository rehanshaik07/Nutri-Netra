// Login functionality
document.addEventListener('DOMContentLoaded', function() {
    // Role selector
    const roleBtns = document.querySelectorAll('.role-btn');
    const userRoleInput = document.getElementById('userRole');
    
    roleBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            roleBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            userRoleInput.value = this.getAttribute('data-role');
        });
    });
    
    // Login form submission
    const loginForm = document.getElementById('loginForm');
    
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const role = document.getElementById('userRole').value;
        
        // Demo validation
        if (role === 'student' && username === 'student@school.com' && password === 'student123') {
            localStorage.setItem('userRole', 'student');
            localStorage.setItem('userName', 'Student User');
            localStorage.setItem('schoolId', '1');
            window.location.href = 'dashboard.html';
        } 
        else if (role === 'admin' && username === 'admin@school.com' && password === 'admin123') {
            localStorage.setItem('userRole', 'admin');
            localStorage.setItem('userName', 'Admin User');
            localStorage.setItem('schoolId', 'all');
            window.location.href = 'dashboard.html';
        }
        else {
            alert('Invalid credentials! Use demo credentials provided.');
        }
    });
});

