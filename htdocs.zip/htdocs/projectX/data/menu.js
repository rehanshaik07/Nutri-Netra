// Weekly Menu Data
const MENU_DATA = {
    currentWeek: "2024-01-15",
    days: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
    
    menu: {
        Monday: {
            breakfast: { name: "Oatmeal with Fresh Fruits", calories: 350, protein: 10, icon: "🥣" },
            lunch: { name: "Grilled Chicken with Brown Rice", calories: 580, protein: 34, icon: "🍗" },
            snack: { name: "Apple Slices with Yogurt", calories: 120, protein: 4, icon: "🍎" }
        },
        Tuesday: {
            breakfast: { name: "Scrambled Eggs with Toast", calories: 420, protein: 18, icon: "🍳" },
            lunch: { name: "Vegetable Pasta with Salad", calories: 520, protein: 15, icon: "🍝" },
            snack: { name: "Banana", calories: 105, protein: 1, icon: "🍌" }
        },
        Wednesday: {
            breakfast: { name: "Smoothie Bowl", calories: 380, protein: 12, icon: "🥤" },
            lunch: { name: "Fish and Chips with Peas", calories: 650, protein: 28, icon: "🐟" },
            snack: { name: "Orange Slices", calories: 62, protein: 1, icon: "🍊" }
        },
        Thursday: {
            breakfast: { name: "Pancakes with Syrup", calories: 450, protein: 8, icon: "🥞" },
            lunch: { name: "Veg Burger with Sweet Potato Fries", calories: 550, protein: 16, icon: "🍔" },
            snack: { name: "Granola Bar", calories: 150, protein: 3, icon: "🍫" }
        },
        Friday: {
            breakfast: { name: "Cereal with Milk", calories: 320, protein: 9, icon: "🥣" },
            lunch: { name: "Pizza with Corn", calories: 600, protein: 20, icon: "🍕" },
            snack: { name: "Fruit Cup", calories: 80, protein: 1, icon: "🍎🍌🍊" }
        }
    },
    
    nutritionInfo: {
        weeklyAverage: { calories: 520, protein: 20, carbs: 45, fat: 15 },
        allergens: ["Nuts", "Dairy", "Gluten", "Eggs"],
        veganOptions: ["Monday Breakfast", "Tuesday Lunch", "Wednesday Breakfast", "Friday Snack"],
        vegetarianOptions: ["Monday Breakfast", "Tuesday Lunch", "Thursday Lunch", "Friday Breakfast"]
    },
    
    getMenuForDay: function(day) {
        return this.menu[day] || null;
    },
    
    getWeekMenu: function() {
        return this.menu;
    },
    
    updateMenuItem: function(day, mealType, itemData) {
        if (this.menu[day] && this.menu[day][mealType]) {
            this.menu[day][mealType] = { ...this.menu[day][mealType], ...itemData };
            return true;
        }
        return false;
    },
    
    getNutritionSummary: function() {
        return this.nutritionInfo;
    }
};

// Export for use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = MENU_DATA;
}

