// School Data
const SCHOOLS_DATA = {
    schools: [
        {
            id: 1,
            name: "Green Valley High School",
            address: "123 Education Blvd, Springfield, IL 62701",
            phone: "+1 (555) 202-1234",
            email: "info@greenvalley.edu",
            principal: "Dr. Angela Hart",
            totalStudents: 1250,
            activeMealProgram: true,
            mealCapacity: 500,
            established: "1995",
            type: "High School"
        },
        {
            id: 2,
            name: "Riverside Academy",
            address: "456 River Road, Springfield, IL 62702",
            phone: "+1 (555) 202-5678",
            email: "contact@riverside.edu",
            principal: "Mr. James Wilson",
            totalStudents: 890,
            activeMealProgram: true,
            mealCapacity: 350,
            established: "2002",
            type: "Middle School"
        },
        {
            id: 3,
            name: "Sunrise Elementary",
            address: "789 Sunrise Blvd, Springfield, IL 62703",
            phone: "+1 (555) 202-9012",
            email: "info@sunrise.edu",
            principal: "Ms. Sarah Johnson",
            totalStudents: 650,
            activeMealProgram: true,
            mealCapacity: 250,
            established: "2010",
            type: "Elementary"
        }
    ],
    
    getSchoolById: function(id) {
        return this.schools.find(school => school.id === parseInt(id));
    },
    
    getAllSchools: function() {
        return this.schools;
    },
    
    addSchool: function(school) {
        school.id = this.schools.length + 1;
        this.schools.push(school);
        return school;
    },
    
    updateSchool: function(id, updatedData) {
        const index = this.schools.findIndex(s => s.id === parseInt(id));
        if (index !== -1) {
            this.schools[index] = { ...this.schools[index], ...updatedData };
            return this.schools[index];
        }
        return null;
    },
    
    deleteSchool: function(id) {
        const index = this.schools.findIndex(s => s.id === parseInt(id));
        if (index !== -1) {
            return this.schools.splice(index, 1)[0];
        }
        return null;
    }
};

// Export for use
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SCHOOLS_DATA;
}

